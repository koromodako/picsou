
Simple script to scan hosts to check basic TLS client compatability.

URL list chosen mostly from large tech/software vendors, feel free to
send suggestions.
